//
//  ViewController.h
//  CodeIQ_AVSpeechSynthesizer
//
//  Created by Mac User on 2014/01/18.
//  Copyright (c) 2014年 HiromiYamamoto. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AVSpeechSynthesizerManager.h"
@interface ViewController : UIViewController

@end
