//
//  main.m
//  CodeIQ_AVSpeechSynthesizer
//
//  Created by Mac User on 2014/01/18.
//  Copyright (c) 2014年 HiromiYamamoto. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
